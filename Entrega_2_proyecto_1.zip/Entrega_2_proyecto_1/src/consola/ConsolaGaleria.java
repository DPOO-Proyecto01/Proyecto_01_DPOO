package consola;

public class ConsolaGaleria 
{
	//Completar
}
