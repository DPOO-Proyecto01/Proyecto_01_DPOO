package galeria.persistencia;

public class PersistenciaProcesos 
{
	public void cargarProcesos (String archivo)
	{
		
	}
	
	public void guardarProcesos (String archivo)
	{
		
	}
	
}
