package galeria.persistencia;

public class PersistenciaUsuarios 
{
	public void cargarUsuarios (String archivo)
	{
		
	}
	
	public void guardarUsuarios (String archivo)
	{
		
	}

}
