package usuarios.modelo;

public class Cajero extends Empleado
{
	Cajero(String _nombre, String _contrasenia, String _tipo, String _rol, Integer _Id) {
		
		super(_nombre, _contrasenia, _tipo = "Cajero", _rol, _Id);
		
	}
	
	
	
}
