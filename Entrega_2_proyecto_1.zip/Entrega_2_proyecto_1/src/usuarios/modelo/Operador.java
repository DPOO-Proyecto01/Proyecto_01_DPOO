package usuarios.modelo;

public class Operador extends Empleado
{

	Operador(String _nombre, String _contrasenia, String _tipo, String _rol, Integer _Id) {
		super(_nombre, _contrasenia, _tipo = "Operador", _rol, _Id);
		// TODO Auto-generated constructor stub
	}
	
}
